# ZVM Panel — LXC runtime release

- VPS provisioning is handled only by LXC system containers through the LXD daemon and `lxc` client.
- Removed Docker and KVM provisioning modules, images, compose files, and installation steps.
- Added an authenticated remote LXD node agent for Railway-hosted control panels.
- Railway is control-plane only; real VPS creation requires a separately managed Linux LXD host.
- VPS creation now records `running` only after the LXC instance is actually initialized and started.
