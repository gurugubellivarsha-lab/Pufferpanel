#!/usr/bin/env python3
"""ZVM authenticated remote LXD node agent.

This agent accepts only the operation grammar implemented by lxd_backend.py.
It never invokes Docker, a shell, or arbitrary host commands.
"""
import os
import asyncio
import platform
import shutil
from flask import Flask, jsonify, request
from lxd_backend import LXDRuntime

app = Flask(__name__)
API_KEY = os.getenv('ZVM_NODE_API_KEY', '')
PORT = int(os.getenv('PORT', '9000'))


def authorized():
    return bool(API_KEY) and request.headers.get('X-API-Key', '') == API_KEY


def deny_unless_authorized():
    if not authorized():
        return jsonify(success=False, error='Unauthorized'), 401
    return None


@app.get('/api/info')
def info():
    denied = deny_unless_authorized()
    if denied:
        return denied
    try:
        host = LXDRuntime.check_host()
        return jsonify(success=True, version='ZVM LXD Node 1.0', python_version=platform.python_version(), lxc=host)
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 503


@app.post('/api/execute')
def execute():
    denied = deny_unless_authorized()
    if denied:
        return denied
    data = request.get_json(silent=True) or {}
    container = str(data.get('container', '')).strip()
    operation = str(data.get('operation', '')).strip()
    timeout = max(1, min(int(data.get('timeout', 120)), 900))
    if not container or not operation:
        return jsonify(success=False, error='container and operation are required'), 400
    try:
        output = asyncio.run(LXDRuntime.run(container, operation, timeout=timeout))
        return jsonify(success=True, stdout=output, stderr='', returncode=0)
    except Exception as exc:
        return jsonify(success=False, error=str(exc), stderr=str(exc), returncode=1), 400


@app.get('/api/status')
def status():
    denied = deny_unless_authorized()
    if denied:
        return denied
    try:
        host = LXDRuntime.check_host()
        return jsonify(success=True, lxc_version=host.get('client_version'), ready=True)
    except Exception as exc:
        return jsonify(success=False, ready=False, error=str(exc)), 503


if __name__ == '__main__':
    if not API_KEY:
        raise SystemExit('ZVM_NODE_API_KEY must be set before starting the remote node agent.')
    app.run(host='0.0.0.0', port=PORT)
