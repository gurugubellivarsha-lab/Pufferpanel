#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./install.sh"; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-pip python3-venv curl ca-certificates
install -d -m 0750 data backups
if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo "Created .env. Set SECRET_KEY and MAIN_ADMIN_PASSWORD before starting."
fi
python3 -m venv venv
venv/bin/python -m pip install --upgrade pip
venv/bin/python -m pip install -r requirements.txt
chmod +x start.sh zvm-tool.sh install-lxc-lxd.sh
venv/bin/python -m py_compile zvm.py lxd_backend.py api.py node.py vps_animation_routes.py
cat <<'EOF'
ZVM Panel Python dependencies installed.
For actual VPS provisioning, install and initialize LXD on a separate Ubuntu/Debian host:
  sudo ./install-lxc-lxd.sh
For Railway, deploy only the panel and register that host as a Remote LXD Node.
Edit .env, then run ./start.sh
EOF
