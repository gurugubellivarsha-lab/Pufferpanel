#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
[[ $EUID -eq 0 ]] || { echo "Run: sudo ./install.sh"; exit 1; }
bash ./install-lxc-lxd.sh
apt-get install -y python3 python3-pip python3-venv
install -d -m 0750 data backups
if [[ ! -f .env ]]; then cp .env.example .env; chmod 600 .env; fi
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt
chmod +x start.sh
venv/bin/python -m py_compile zvm.py lxd_backend.py api.py node.py vps_animation_routes.py
printf '\nZVM Panel installed. Set .env secrets and run ./start.sh\n'
