#!/usr/bin/env python3
"""LXD container runtime adapter used by ZVM Panel V2.

Requires a configured LXD daemon and the `lxc` client on the panel host/node. All guests are LXC system containers managed by LXD.
This manages system containers (not hardware-virtualized KVM VMs).
"""
from __future__ import annotations
import asyncio
import json
import os
import re
import shlex
import shutil
import socket
import subprocess


class LXDRuntime:
    DEFAULT_IMAGE = os.getenv('ZVM_LXD_DEFAULT_IMAGE', 'ubuntu:22.04')
    SSH_PORT_MIN = int(os.getenv('ZVM_SSH_PORT_MIN', '22000'))
    SSH_PORT_MAX = int(os.getenv('ZVM_SSH_PORT_MAX', '22999'))

    @staticmethod
    def _name(value: str) -> str:
        value = (value or '').strip()
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}', value):
            raise ValueError('Invalid LXD instance name')
        return value

    @staticmethod
    def _image(value: str) -> str:
        value = (value or LXDRuntime.DEFAULT_IMAGE).strip()
        aliases = {
            'images:debian/10': 'images:debian/10',
            'images:debian/11': 'images:debian/11',
            'images:debian/12': 'images:debian/12',
            'images:debian/13': 'images:debian/13',
            'ubuntu:20.04': 'ubuntu:20.04',
            'ubuntu:22.04': 'ubuntu:22.04',
            'ubuntu:24.04': 'ubuntu:24.04',
        }
        return aliases.get(value, value)

    @staticmethod
    def _run_sync(args, timeout=120, check=True):
        if not shutil.which(args[0]):
            raise RuntimeError(f"Required command '{args[0]}' is not installed. Install and initialize LXD first.")
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
        if check and p.returncode:
            raise RuntimeError((p.stderr or p.stdout).strip() or f"LXD command failed ({p.returncode})")
        return p.stdout.strip()

    @classmethod
    def check_host(cls):
        version = cls._run_sync(['lxc', 'version'], timeout=15)
        cls._run_sync(['lxc', 'info'], timeout=20)
        return {'client_version': version, 'ready': True}

    @classmethod
    def exists(cls, name):
        name = cls._name(name)
        p = subprocess.run(['lxc', 'info', name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return p.returncode == 0

    @classmethod
    def _alloc_ssh_port(cls):
        for port in range(cls.SSH_PORT_MIN, cls.SSH_PORT_MAX + 1):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                try:
                    s.bind(('0.0.0.0', port))
                    return port
                except OSError:
                    continue
        raise RuntimeError(f'No free SSH host port in {cls.SSH_PORT_MIN}-{cls.SSH_PORT_MAX}')

    @classmethod
    def _instance_json(cls, name):
        raw = cls._run_sync(['lxc', 'list', name, '--format', 'json'])
        rows = json.loads(raw or '[]')
        for row in rows:
            if row.get('name') == name:
                return row
        raise RuntimeError(f'LXD instance {name} was not found')

    @classmethod
    def _ip(cls, name):
        row = cls._instance_json(name)
        for nic in row.get('state', {}).get('network', {}).values():
            for addr in nic.get('addresses', []):
                if addr.get('family') == 'inet' and not addr.get('address', '').startswith('127.'):
                    return addr['address']
        return ''

    @classmethod
    def create(cls, name, image=None, ram_mb=None, cpu=None, disk_gb=None):
        name = cls._name(name)
        if cls.exists(name):
            raise RuntimeError(f'LXD instance {name} already exists')
        image = cls._image(image)
        args = ['lxc', 'init', image, name]
        if ram_mb:
            ram_mb = int(ram_mb)
            if ram_mb < 128:
                raise ValueError('RAM limit must be at least 128 MB')
            args += ['--config', f'limits.memory={ram_mb}MB']
        if cpu:
            cpu = float(cpu)
            if cpu < 0.1:
                raise ValueError('CPU limit must be at least 0.1')
            args += ['--config', f'limits.cpu.allowance={max(1, int(cpu * 100))}%']
        if disk_gb:
            disk_gb = int(disk_gb)
            if disk_gb < 1:
                raise ValueError('Disk limit must be at least 1 GB')
            # Apply the size to the root disk device after initialization; the default profile supplies it.
        cls._run_sync(args, timeout=600)
        try:
            if disk_gb:
                cls._run_sync(['lxc', 'config', 'device', 'set', name, 'root', 'size', f'{disk_gb}GB'])
        except Exception:
            cls._run_sync(['lxc', 'delete', name, '--force'], check=False)
            raise
        # SSH exposure is created only when an explicit panel port-forward is requested.
        return True

    @classmethod
    def update(cls, name, privileged=False, ram_mb=None, cpu=None):
        name = cls._name(name)
        if ram_mb:
            cls._run_sync(['lxc', 'config', 'set', name, 'limits.memory', f'{int(ram_mb)}MB'])
        if cpu:
            cls._run_sync(['lxc', 'config', 'set', name, 'limits.cpu.allowance', f'{max(1, int(float(cpu) * 100))}%'])

    @classmethod
    def _proxy_add(cls, name, command):
        name = cls._name(name)
        m_listen = re.search(r'listen=(tcp|udp):(?:0\.0\.0\.0|\[::\]):(\d+)', command)
        m_connect = re.search(r'connect=(?:tcp|udp):(?:127\.0\.0\.1|localhost):(\d+)', command)
        m_device = re.search(r'config device add\s+\S+\s+(\S+)', command)
        if not (m_listen and m_connect and m_device):
            raise ValueError('Unsupported proxy device configuration')
        proto, host_port = m_listen.group(1), int(m_listen.group(2))
        target_port, device = int(m_connect.group(1)), m_device.group(1)
        cls._run_sync(['lxc', 'config', 'device', 'add', name, device, 'proxy',
                       f'listen={proto}:0.0.0.0:{host_port}', f'connect={proto}:127.0.0.1:{target_port}',
                       'bind=host'])
        return True

    @classmethod
    def _proxy_remove(cls, name, command):
        name = cls._name(name)
        m = re.search(r'config device remove\s+\S+\s+(\S+)', command)
        if not m:
            m = re.search(r'(tcp|udp)_proxy_(\d+)', command)
            device = f'{m.group(1)}_proxy_{m.group(2)}' if m else None
        else:
            device = m.group(1)
        if device:
            cls._run_sync(['lxc', 'config', 'device', 'remove', name, device], check=False)
        return True

    @classmethod
    async def run(cls, name, command, timeout=120):
        def work():
            c = (command or '').strip()
            parts = shlex.split(c)
            if not parts:
                return True
            op = parts[0]
            if op == 'init':
                image = parts[1] if len(parts) > 1 else cls.DEFAULT_IMAGE
                cname = parts[2] if len(parts) > 2 else name
                ram = cpu = disk = None
                i = 3
                while i < len(parts):
                    token = parts[i]
                    if token in ('-m', '--memory') and i + 1 < len(parts):
                        raw = parts[i + 1].lower(); num = re.sub(r'[^0-9.]', '', raw)
                        ram = int(float(num) * (1024 if raw.endswith(('gb', 'g')) else 1)); i += 2; continue
                    if token in ('-c', '--cpus') and i + 1 < len(parts):
                        cpu = float(parts[i + 1]); i += 2; continue
                    if token in ('-d', '--disk') and i + 1 < len(parts):
                        disk = int(float(re.sub(r'[^0-9.]', '', parts[i + 1]))); i += 2; continue
                    i += 1
                return str(cls.create(cname, image, ram, cpu, disk))
            if op in {'start', 'stop', 'restart', 'freeze', 'unfreeze', 'delete'}:
                target = cls._name(parts[1] if len(parts) > 1 else name)
                action = {'unfreeze': 'unfreeze', 'delete': 'delete'}.get(op, op)
                args = {'start': ['start'], 'stop': ['stop'], 'restart': ['restart'],
                        'freeze': ['freeze'], 'unfreeze': ['unfreeze'], 'delete': ['delete', '--force']}[action]
                cls._run_sync(['lxc'] + args + [target], timeout=timeout)
                return True
            if op == 'info':
                target = cls._name(parts[1] if len(parts) > 1 else name)
                row = cls._instance_json(target)
                return f"Status: {row.get('status', 'Unknown')}\nIP: {cls._ip(target)}\n"
            if op == 'config' and len(parts) >= 5 and parts[1] == 'set':
                target, key, value = cls._name(parts[2]), parts[3], parts[4]
                if key == 'limits.memory': value = re.sub(r'(?i)mb$', 'MB', value)
                if key == 'limits.cpu': key, value = 'limits.cpu.allowance', f'{max(1, int(float(value) * 100))}%'
                cls._run_sync(['lxc', 'config', 'set', target, key, value])
                return True
            if op == 'config' and len(parts) >= 5 and parts[1] == 'device' and parts[2] == 'add':
                return cls._proxy_add(name, c)
            if op == 'config' and len(parts) >= 5 and parts[1] == 'device' and parts[2] == 'remove':
                return cls._proxy_remove(name, c)
            if op == 'config' and len(parts) >= 6 and parts[1] == 'device' and parts[2] == 'set':
                cls._run_sync(['lxc', 'config', 'device', 'set'] + parts[3:])
                return True
            if op == 'exec':
                rest = c[len('exec '):]
                if ' -- ' in rest:
                    cname, payload = rest.split(' -- ', 1)
                    cname = cls._name(cname.strip())
                    payload = payload.lstrip()
                    if len(payload) >= 2 and payload[0] in ('\'', '"') and payload[-1] == payload[0]:
                        decoded = shlex.split(payload)
                        if len(decoded) == 1: payload = decoded[0]
                else:
                    cname = cls._name(parts[1])
                    payload = ' '.join(parts[2:])
                return cls._run_sync(['lxc', 'exec', cname, '--', 'sh', '-lc', payload], timeout=timeout)
            # Reject unknown commands; only supported LXD operations are accepted.
            raise ValueError(f'Unsupported ZVM runtime operation: {op}')
        return await asyncio.to_thread(work)

    @staticmethod
    def translate_command(name, command):
        c = (command or '').strip()
        parts = shlex.split(c)
        if not parts: return ''
        op = parts[0]
        if op in {'start', 'stop', 'restart', 'freeze', 'unfreeze', 'delete'}:
            action = {'delete': 'delete --force'}.get(op, op)
            return f'lxc {action} {shlex.quote(name)}'
        if op == 'info': return f'lxc info {shlex.quote(name)}'
        if op == 'exec':
            rest = c[len('exec '):]
            if ' -- ' in rest:
                cname, payload = rest.split(' -- ', 1)
                return f'lxc exec {shlex.quote(cname.strip())} -- sh -lc {shlex.quote(payload.lstrip())}'
            if len(parts) >= 3:
                return f'lxc exec {shlex.quote(parts[1])} -- sh -lc {shlex.quote(" ".join(parts[2:]))}'
        if op == 'config' and len(parts) >= 5 and parts[1] == 'set':
            key, value = parts[3], parts[4]
            if key == 'limits.cpu': return f'lxc config set {shlex.quote(name)} limits.cpu.allowance {shlex.quote(str(max(1, int(float(value)*100)))+"%")}'
            return f'lxc config set {shlex.quote(name)} {shlex.quote(key)} {shlex.quote(value)}'
        if op == 'config':
            return 'lxc ' + ' '.join(shlex.quote(x) for x in parts[1:])
        if op == 'init':
            # Build a safe LXD command string for diagnostics/legacy callers.
            image = parts[1] if len(parts) > 1 else LXDRuntime.DEFAULT_IMAGE
            cname = parts[2] if len(parts) > 2 else name
            args = ['lxc', 'init', image, cname]
            disk = None
            i = 3
            while i < len(parts):
                token = parts[i]
                if token in ('-m', '--memory') and i + 1 < len(parts):
                    raw = parts[i + 1].lower(); num = re.sub(r'[^0-9.]', '', raw)
                    mb = int(float(num) * (1024 if raw.endswith(('gb', 'g')) else 1))
                    args += ['--config', f'limits.memory={mb}MB']; i += 2; continue
                if token in ('-c', '--cpus') and i + 1 < len(parts):
                    args += ['--config', f'limits.cpu.allowance={max(1, int(float(parts[i+1])*100))}%']; i += 2; continue
                if token in ('-d', '--disk') and i + 1 < len(parts):
                    disk = int(float(re.sub(r'[^0-9.]', '', parts[i+1]))); i += 2; continue
                i += 1
            command = ' '.join(shlex.quote(x) for x in args)
            if disk:
                command += ' && lxc config device set ' + shlex.quote(cname) + ' root size ' + shlex.quote(f'{disk}GB')
            return command
        return 'lxc ' + ' '.join(shlex.quote(x) for x in parts)
