# ZVM Panel — LXD-only VPS manager

This is Zahira’s ZVM Panel build. It uses the supplied templates, rebranded throughout for ZVM Panel, with an LXD-only VPS provisioning backend.

## Member limits
- Each newly registered standard member can create exactly one VPS.
- The member creation API ignores submitted resource values and provisions exactly 1 CPU core, 2 GB RAM, and 5 GB disk.
- Members cannot create a second VPS.

## Administrator controls
- Administrators use `/admin/vps/create` and can choose resources for each VPS.
- Defaults for administrator maximums are 256 CPU cores and 10,000 GB disk; override with `ZVM_ADMIN_MAX_CPU` and `ZVM_ADMIN_MAX_DISK_GB`. RAM validation remains capped at 128 GB in the inherited admin form.
- Administrators can create additional VPS instances for a member.

## Install (Ubuntu/Debian host with systemd)
```bash
sudo ./install.sh
```
Set a strong `SECRET_KEY`, admin password, and `MAIN_ADMIN_EMAIL` in `.env`, then run:
```bash
./start.sh
```
Panel listens on port 3000 by default.

## Important LXD requirements
LXD provisions system containers, not hardware-virtualized KVM VMs. The host needs systemd, Snap services, kernel namespaces/cgroups, bridge/networking support, and the privileges required by LXD. A standard Railway application container generally cannot provide these host-level capabilities. Run the LXD daemon on a dedicated Ubuntu/Debian VPS or supported host and connect the panel to that host using a secured LXD node setup.

## Templates
The contents of `templates/` are copied from the supplied ZVM archive and intentionally left unchanged. The app passes `ZVM Panel` as its default panel name through backend context/settings. Existing hard-coded visual text in templates, if any, is intentionally not rewritten per the request.
