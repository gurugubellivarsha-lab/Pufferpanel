# ZVM Panel

ZVM Panel is a Python 3 / Flask control panel. **VPS provisioning uses LXC system containers managed by LXD only.** There is no Docker or KVM provisioning backend in this release.

## Important deployment architecture

- Railway may host the web panel, login, dashboard, API, and database only.
- Actual VPS containers must run on a separate Ubuntu/Debian Linux host with a working LXD daemon, kernel namespaces, cgroups, storage pool, and network bridge.
- Register that machine in Admin → Nodes as a **Remote** node. Run `node.py` there with the same `ZVM_NODE_API_KEY` stored for the node.
- Railway managed services do not provide the host-level privileges required to run an LXD daemon and create nested LXC containers. The panel deliberately rejects local provisioning when it detects Railway.

## Run the panel

```bash
cp .env.example .env
# Edit .env and set strong SECRET_KEY and MAIN_ADMIN_PASSWORD
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python3 zvm.py
```

The panel listens on `0.0.0.0:3000` by default.

## Prepare a dedicated LXD VPS node

On a supported Ubuntu/Debian host with systemd and root access:

```bash
sudo ./install-lxc-lxd.sh
```

The installer installs LXC/LXD and initializes the LXD daemon. Review storage and networking before exposing the host to production. Do not run the installer inside Railway.

Start the remote node agent on the LXD host:

```bash
export ZVM_NODE_API_KEY='use-the-same-long-random-key-as-the-panel-node-record'
export PORT=9000
python3 node.py
```

Place the agent behind HTTPS/reverse proxy or a private network/VPN. Never expose it publicly without TLS and a strong API key. The node agent only accepts the operation grammar in `lxd_backend.py`; it does not execute arbitrary host shell commands.

## Railway

Railway deploys the Python panel using `railway.toml`. Set a persistent volume for `zvm.db` and uploads if they must survive redeploys. Set `SECRET_KEY`, `MAIN_ADMIN_PASSWORD`, and other environment variables in Railway Variables. Add your remote LXD node in the admin panel after deployment.

## Security and limitations

- LXC containers share the host kernel; they are system containers, not hardware-virtualized KVM machines.
- A public SSH port proxy is allocated on the LXD node in the configured range. Open that range in the host firewall if you intend to use it.
- Guest static IPv4 requires an address valid for the LXD network and a network that supports static assignments. Confirm subnet and gateway on the node.
- Change the initial admin password immediately. Use a unique node API key and HTTPS/VPN for node traffic.
- Verify backups, storage quotas, network isolation, and resource limits before selling hosting plans.
