#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo ./install-lxc-lxd.sh"; exit 1; }
source /etc/os-release
[[ "${ID:-}" == ubuntu || "${ID:-}" == debian ]] || { echo "Ubuntu/Debian required"; exit 1; }
[[ "$(ps -p 1 -o comm= | tr -d ' ')" == systemd ]] || { echo "ERROR: systemd is required. Install LXD on a supported Linux host, not inside an ordinary Railway service."; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
# Do not install the legacy standalone LXC tools package: LXD's snap supplies
# the matching `lxc` client used by this project.
apt-get install -y snapd squashfs-tools fuse3 uidmap bridge-utils curl
systemctl enable --now snapd.socket
for i in $(seq 1 45); do snap version >/dev/null 2>&1 && break; sleep 2; done
snap version >/dev/null 2>&1 || { echo "Snap daemon did not become ready"; exit 1; }
if ! snap list lxd >/dev/null 2>&1; then snap install lxd; fi
[[ -x /snap/bin/lxc ]] || { echo "LXD snap did not provide /snap/bin/lxc"; exit 1; }
[[ -x /snap/bin/lxd ]] || { echo "LXD daemon binary is missing"; exit 1; }
# Ensure non-login service environments can resolve the LXD client/daemon.
ln -sf /snap/bin/lxc /usr/local/bin/lxc
ln -sf /snap/bin/lxd /usr/local/bin/lxd
if ! /usr/local/bin/lxc info >/dev/null 2>&1; then /usr/local/bin/lxd init --minimal; fi
/usr/local/bin/lxc version
/usr/local/bin/lxc info >/dev/null
printf '\nLXC system-container runtime is ready (managed by LXD).\n'
printf 'Review the default storage pool and network bridge before production use.\n'
