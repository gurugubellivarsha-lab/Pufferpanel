#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo ./install-lxc-lxd.sh"; exit 1; }
source /etc/os-release
[[ "${ID:-}" == ubuntu || "${ID:-}" == debian ]] || { echo "Ubuntu/Debian required"; exit 1; }
[[ "$(ps -p 1 -o comm= | tr -d ' ')" == systemd ]] || { echo "ERROR: systemd is required. Install LXD on a supported Ubuntu/Debian host, not an ordinary Railway container."; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y snapd squashfs-tools fuse3 lxc lxc-utils uidmap bridge-utils
systemctl enable --now snapd.socket
for i in $(seq 1 30); do snap version >/dev/null 2>&1 && break; sleep 2; done
snap version >/dev/null 2>&1 || { echo "Snap daemon did not become ready"; exit 1; }
if ! snap list lxd >/dev/null 2>&1; then snap install lxd; fi
command -v lxd >/dev/null 2>&1 || { echo "LXD command missing after snap install"; exit 1; }
if ! lxc info >/dev/null 2>&1; then lxd init --minimal; fi
lxc version
lxc info >/dev/null
 echo "LXC + LXD + Snap setup complete."
