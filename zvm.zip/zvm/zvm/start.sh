#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
# Use 8000 locally; hosting platforms such as Railway override PORT automatically.
export HOST="${HOST:-0.0.0.0}"
export PORT="${PORT:-8000}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
command -v "$PYTHON_BIN" >/dev/null || { echo "Python 3 required"; exit 1; }
[[ -d venv ]] || "$PYTHON_BIN" -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
exec python zvm.py
