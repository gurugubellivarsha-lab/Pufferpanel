#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ ! -d venv ]]; then python3 -m venv venv; fi
source venv/bin/activate
python -m pip install --disable-pip-version-check -r requirements.txt
exec python3 zvm.py
