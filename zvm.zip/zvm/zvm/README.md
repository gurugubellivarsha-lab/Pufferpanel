# ZVM Panel — Docker edition

This package keeps the existing ZVM Panel dashboard, authentication, admin area, VPS pages, file manager and console, and replaces the previous LXD runtime adapter with a Docker Engine adapter.

## Architecture

- **Panel:** Flask application on port `3000`.
- **Provisioning:** Docker containers created on a dedicated Ubuntu/Debian Docker host.
- **Railway:** hosts the web control panel only. Railway's container is not the Docker host for customer workloads.
- **Remote node:** `node.py` exposes authenticated `/api/execute` operations on port `9000`; place it behind HTTPS and restrict inbound traffic.

## Important Docker limitations

Docker containers are Linux containers, **not full hardware-virtualized VPS machines**. The current adapter enforces memory and CPU limits, persists each container's writable layer, maps an SSH host port, and supports start/stop/restart/exec/stats. The requested disk size is recorded as metadata but Docker's default storage driver does not enforce a per-container disk quota here. Static guest IPv4 assignment and adding arbitrary published ports after creation are not supported by this adapter. Containers do not run systemd by default. Do not advertise these as KVM VMs or promise Windows VPS support.

## Quick start: single Ubuntu/Debian Docker host

1. Install Docker Engine and the Compose plugin using Docker's official installation instructions.
2. Copy `.env.example` to `.env`; set a long random `SECRET_KEY`, a strong `MAIN_ADMIN_PASSWORD`, and `ZVM_NODE_API_KEY`.
3. Run:

```bash
docker compose up -d --build
docker compose logs -f zvm-panel
```

Open `http://YOUR_SERVER_IP:3000`.

The compose file mounts the Docker socket into the panel and node services. This gives them host-level Docker control; use only on a server you administer.

## Railway + remote Docker node

1. Deploy this repository to Railway using the included `Dockerfile` / `railway.toml`.
2. Set `SECRET_KEY`, `MAIN_ADMIN_PASSWORD`, `DATABASE_PATH` (use a persistent volume, e.g. `/data/zvm.db`) and other environment variables in Railway.
3. On a separate Ubuntu/Debian host with a public reachable address, copy the project and run:

```bash
sudo bash docker-node-install.sh
```

4. Set the same strong `ZVM_NODE_API_KEY` in the node `.env`, then run the node agent under a process manager. Use HTTPS reverse proxy and firewall port `9000` so only the Railway panel can reach it.
5. In ZVM Panel Admin > Nodes, add the node's HTTPS base URL and the same API key. Mark it as a remote node, not local.

## Node agent

```bash
set -a; source .env; set +a
venv/bin/python node.py
```

The agent refuses requests unless `X-API-Key` matches `ZVM_NODE_API_KEY`.

## Checks

```bash
python -m py_compile zvm.py docker_backend.py api.py node.py vps_animation_routes.py
docker version
docker info
```

Back up the database and Docker volumes before upgrades. Never expose the Docker socket or unauthenticated node API to the public internet.
