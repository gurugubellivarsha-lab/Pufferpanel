#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ $EUID -ne 0 ]]; then echo 'Run with sudo: sudo ./install.sh'; exit 1; fi
apt-get update
apt-get install -y python3 python3-pip python3-venv curl ca-certificates
install -d -m 0750 data backups
if [[ ! -f .env ]]; then cp .env.example .env; chmod 600 .env; echo 'Edit .env and set SECRET_KEY, MAIN_ADMIN_PASSWORD and ZVM_NODE_API_KEY.'; fi
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt
chmod +x start.sh zvm-tool.sh docker-node-install.sh
venv/bin/python -m py_compile zvm.py docker_backend.py api.py node.py vps_animation_routes.py
cat <<'MSG'
ZVM Panel installed.
For a single Ubuntu host, install Docker Engine and run docker compose up -d.
For Railway, deploy the panel only; install Docker Engine on a separate Ubuntu/Debian node,
run docker-node-install.sh there, then register its HTTPS URL and API key in Admin > Nodes.
MSG
