#!/usr/bin/env bash
set -eu
printf '%s\n' '=== ZVM QEMU/KVM host check ==='
printf '\nOS: '; . /etc/os-release; echo "${PRETTY_NAME:-unknown}"
printf '\nKernel: '; uname -r
printf '\n/dev/kvm: '
if [ -e /dev/kvm ]; then ls -l /dev/kvm; else echo 'MISSING — hardware virtualization/KVM is unavailable'; fi
printf '\nCPU virtualization flags: '
if grep -qm1 -E '(vmx|svm)' /proc/cpuinfo; then echo 'present'; else echo 'not exposed'; fi
for c in qemu-system-x86_64 virsh qemu-img; do
  printf '%-22s' "$c"
  command -v "$c" || true
done
printf '\nLibvirt status:\n'
if command -v virsh >/dev/null 2>&1; then virsh list --all || true; else echo 'virsh not installed'; fi
printf '\nThis script only checks prerequisites; it does not install or create VMs.\n'
