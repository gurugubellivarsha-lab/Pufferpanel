#!/usr/bin/env python3
"""Docker container runtime adapter for ZVM Panel.

Important: Docker containers are isolated Linux containers, not hardware VMs.
Run this adapter on a dedicated Ubuntu/Debian Docker host (or remote node agent).
"""
from __future__ import annotations
import asyncio, json, os, re, shlex, shutil, socket, subprocess

class LXDRuntime:  # Compatibility name: zvm.py imports this symbol.
    DEFAULT_IMAGE = os.getenv('ZVM_DOCKER_DEFAULT_IMAGE', 'ubuntu:24.04')
    SSH_PORT_MIN = int(os.getenv('ZVM_SSH_PORT_MIN', '22000'))
    SSH_PORT_MAX = int(os.getenv('ZVM_SSH_PORT_MAX', '22999'))

    @staticmethod
    def _name(value):
        value=(value or '').strip()
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}', value): raise ValueError('Invalid Docker container name')
        return value

    @staticmethod
    def _run_sync(args, timeout=120, check=True):
        if not shutil.which('docker'): raise RuntimeError('Docker CLI is missing. Install Docker Engine on the provisioning host.')
        p=subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
        if check and p.returncode: raise RuntimeError((p.stderr or p.stdout).strip() or f'Docker command failed ({p.returncode})')
        return p.stdout.strip()

    @classmethod
    def check_host(cls):
        version=cls._run_sync(['docker','version','--format','{{.Server.Version}}'],timeout=15)
        info=json.loads(cls._run_sync(['docker','info','--format','{{json .}}'],timeout=20))
        return {'client_version':version,'server_version':version,'ready':True,'containers':info.get('Containers',0),'driver':info.get('Driver','unknown')}

    @classmethod
    def exists(cls,name):
        name=cls._name(name)
        p=subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return p.returncode==0

    @classmethod
    def _alloc_ssh_port(cls):
        for port in range(cls.SSH_PORT_MIN,cls.SSH_PORT_MAX+1):
            with socket.socket() as s:
                try: s.bind(('0.0.0.0',port)); return port
                except OSError: pass
        raise RuntimeError(f'No free SSH host port in {cls.SSH_PORT_MIN}-{cls.SSH_PORT_MAX}')

    @classmethod
    def create(cls,name,image=None,ram_mb=None,cpu=None,disk_gb=None):
        name=cls._name(name); image=(image or cls.DEFAULT_IMAGE).strip()
        image_aliases={'images:debian/10':'debian:10','images:debian/11':'debian:11','images:debian/12':'debian:12','images:debian/13':'debian:13'}
        image=image_aliases.get(image,image)
        if not re.fullmatch(r'[a-zA-Z0-9./:_-]{1,180}',image): raise ValueError('Invalid Docker image')
        if cls.exists(name): raise RuntimeError(f'Container {name} already exists')
        ram_mb=max(256,int(ram_mb or 1024)); cpu=max(0.25,float(cpu or 1)); ssh_port=cls._alloc_ssh_port()
        cls._run_sync(['docker','pull',image],timeout=900)
        args=['docker','create','--name',name,'--hostname',name,'--restart','unless-stopped',
              '--memory',f'{ram_mb}m','--memory-swap',f'{ram_mb}m','--cpus',str(cpu),
              '--pids-limit','2048','--cap-add','NET_ADMIN','--cap-add','NET_RAW',
              '--device','/dev/net/tun:/dev/net/tun','-p',f'{ssh_port}:22',
              '--label','zvm.managed=true','--label',f'zvm.disk.requested_gb={int(disk_gb or 10)}',
              image,'sh','-lc','while :; do sleep 3600; done']
        # TUN is optional on hosts without /dev/net/tun.
        if not os.path.exists('/dev/net/tun'):
            i=args.index('--device'); del args[i:i+2]
        try: cls._run_sync(args,timeout=180)
        except Exception:
            cls._run_sync(['docker','rm','-f',name],check=False); raise
        return {'name':name,'ssh_port':ssh_port,'disk_limit_enforced':False}

    @classmethod
    async def run(cls,name,command,timeout=120):
        name=cls._name(name); parts=shlex.split((command or '').strip())
        if not parts: raise ValueError('Empty Docker operation')
        op=parts[0]
        if op=='init':
            if len(parts)<3: raise ValueError('init requires image and container name')
            image,cname=parts[1],cls._name(parts[2]); ram=1024; cpu=1; disk=10; i=3
            while i<len(parts):
                if parts[i] in ('-m','--memory') and i+1<len(parts): ram=int(float(re.sub('[^0-9.]','',parts[i+1]))*(1024 if parts[i+1].lower().endswith('gb') else 1)); i+=2
                elif parts[i] in ('-c','--cpu') and i+1<len(parts): cpu=float(parts[i+1]); i+=2
                elif parts[i] in ('-d','--disk') and i+1<len(parts): disk=int(float(re.sub('[^0-9.]','',parts[i+1]))); i+=2
                else: i+=1
            result=cls.create(cname,image,ram,cpu,disk)
            return json.dumps({'name':cname,'status':'created',**result})
        if op in ('start','stop','restart','freeze','unfreeze','unpause','pause'):
            target=parts[1] if len(parts)>1 else name
            action={'freeze':'pause','unfreeze':'unpause'}.get(op,op)
            extra=['-t','5'] if action in ('stop','restart') else []
            return cls._run_sync(['docker',action]+extra+[cls._name(target)],timeout=timeout)
        if op=='delete':
            target=parts[1] if len(parts)>1 else name
            return cls._run_sync(['docker','rm','-f',cls._name(target)],timeout=timeout)
        if op=='info':
            target=parts[1] if len(parts)>1 else name
            raw=cls._run_sync(['docker','inspect',cls._name(target)])
            d=json.loads(raw)[0]; state=d.get('State',{}); net=(d.get('NetworkSettings',{}).get('Networks') or {})
            ip=next((v.get('IPAddress') for v in net.values() if v.get('IPAddress')), '')
            return f"Status: {'Running' if state.get('Running') else 'Stopped'}\nIPv4: {ip}\nDocker: true"
        if op=='exec':
            try: sep=parts.index('--')
            except ValueError: raise ValueError('exec syntax: exec CONTAINER -- COMMAND')
            target=cls._name(parts[1] if len(parts)>1 else name); payload=(command.split('--',1)[1] if '--' in command else '').strip()
            if not payload: raise ValueError('Empty exec command')
            return cls._run_sync(['docker','exec',target,'sh','-lc',payload],timeout=timeout)
        if op=='config':
            # Compatibility for the panel's port-forward feature: run a tiny host-network
            # socat sidecar that forwards host_port to the target container's bridge IP.
            if len(parts)>2 and parts[1]=='device' and parts[2]=='add' and 'proxy' in parts:
                device=parts[3]; spec=' '.join(parts[4:]); m=re.search(r'listen=(tcp|udp):0\.0\.0\.0:(\d+).*connect=(tcp|udp):127\.0\.0\.1:(\d+)',spec)
                if not m: raise ValueError('Unsupported Docker proxy definition')
                proto,host_port,dproto,guest_port=m.groups(); host_port=int(host_port); guest_port=int(guest_port)
                inspect=json.loads(cls._run_sync(['docker','inspect',name]))[0]
                nets=inspect.get('NetworkSettings',{}).get('Networks',{})
                guest_ip=next((v.get('IPAddress') for v in nets.values() if v.get('IPAddress')),None)
                if not guest_ip: raise RuntimeError('Container has no Docker bridge IP')
                helper=cls._name(f'zvm-pf-{name}-{host_port}-{proto}')
                cls._run_sync(['docker','rm','-f',helper],check=False)
                cls._run_sync(['docker','pull','alpine/socat'],timeout=600)
                listen=f'{proto.upper()}-LISTEN:{host_port},fork,reuseaddr' if proto=='tcp' else f'UDP-RECVFROM:{host_port},fork'
                dest=f'{dproto.upper()}:{guest_ip}:{guest_port}' if proto=='tcp' else f'UDP-SENDTO:{guest_ip}:{guest_port}'
                cls._run_sync(['docker','run','-d','--name',helper,'--restart','unless-stopped','--network','host','alpine/socat','-d',listen,dest],timeout=120)
                return f'Forwarding {proto.upper()} {host_port} -> {guest_ip}:{guest_port}'
            if len(parts)>3 and parts[1]=='device' and parts[2]=='remove':
                device=parts[3]; m=re.search(r'(\d+)',device)
                if m:
                    host_port=m.group(1)
                    for proto in ('tcp','udp'):
                        cls._run_sync(['docker','rm','-f',f'zvm-pf-{name}-{host_port}-{proto}'],check=False)
                    return 'Port forward removed'
            if len(parts)>1 and parts[1]=='device' and 'ipv4.address' in parts:
                raise RuntimeError('Docker assigns private IPs automatically; static IPv4 assignment is not supported.')
            raise RuntimeError('Unsupported Docker network configuration operation.')
        raise ValueError(f'Unsupported Docker operation: {op}')
