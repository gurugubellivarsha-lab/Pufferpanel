#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; PURPLE='\033[0;35m'; CYAN='\033[0;36m'; NC='\033[0m'
while true; do
  clear || true
  echo -e "${PURPLE}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${PURPLE}║${NC}                 ${CYAN}ZVM PANEL TOOLS${NC}                   ${PURPLE}║${NC}"
  echo -e "${PURPLE}╚══════════════════════════════════════════════════════╝${NC}"
  echo -e "  ${CYAN}1.${NC} Start ZVM Panel"
  echo -e "  ${CYAN}2.${NC} Install Docker Engine (Linux host only)"
  echo -e "  ${CYAN}3.${NC} Check Docker Engine status"
  echo -e "  ${CYAN}4.${NC} Start remote Docker node agent"
  echo -e "  ${CYAN}5.${NC} Cloudflare Tunnel Setup"
  echo -e "  ${RED}0.${NC} Exit"
  read -r -p 'Choose [0-5]: ' choice
  case "$choice" in
    1) exec python3 zvm.py ;;
    2) sudo bash docker-node-install.sh ;;
    3) if command -v docker >/dev/null 2>&1; then docker version; docker info; else echo -e "${YELLOW}Docker Engine is not installed."; fi ;;
    4) : "${ZVM_NODE_API_KEY:?Set ZVM_NODE_API_KEY first}"; python3 node.py ;;
    5)
      sudo apt-get update -y && sudo apt-get install -y curl
      curl -fsSL https://pkg.cloudflare.com/cloudflare-public-v2.gpg | sudo tee /usr/share/keyrings/cloudflare-public-v2.gpg >/dev/null
      echo 'deb [signed-by=/usr/share/keyrings/cloudflare-public-v2.gpg] https://pkg.cloudflare.com/cloudflared any main' | sudo tee /etc/apt/sources.list.d/cloudflared.list >/dev/null
      sudo apt-get update -y && sudo apt-get install -y cloudflared
      read -r -s -p 'Cloudflare Tunnel Token: ' token; echo
      [[ -n "$token" ]] && sudo cloudflared service install "$token"
      ;;
    0) exit 0 ;;
    *) echo -e "${RED}Invalid choice.${NC}" ;;
  esac
  read -r -p 'Press Enter to continue...' _
done
