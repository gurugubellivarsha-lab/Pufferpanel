#!/usr/bin/env python3
"""Authenticated remote Docker provisioning node for ZVM Panel."""
import os, asyncio, platform, subprocess
from flask import Flask, jsonify, request
from docker_backend import LXDRuntime
app=Flask(__name__)
API_KEY=os.getenv('ZVM_NODE_API_KEY','')
PORT=int(os.getenv('PORT','9000'))

def authorized(): return bool(API_KEY) and request.headers.get('X-API-Key','')==API_KEY

def deny(): return (jsonify(success=False,error='Unauthorized'),401) if not authorized() else None

@app.get('/api/info')
def info():
    d=deny()
    if d:return d
    try:return jsonify(success=True,version='ZVM Docker Node 1.0',python_version=platform.python_version(),docker=LXDRuntime.check_host())
    except Exception as e:return jsonify(success=False,error=str(e)),503

@app.post('/api/execute')
def execute():
    d=deny()
    if d:return d
    data=request.get_json(silent=True) or {}; container=str(data.get('container','')).strip(); operation=str(data.get('operation','')).strip()
    timeout=max(1,min(int(data.get('timeout',120)),900))
    if not container or not operation:return jsonify(success=False,error='container and operation are required'),400
    try:
        output=asyncio.run(LXDRuntime.run(container,operation,timeout=timeout))
        return jsonify(success=True,stdout=output,stderr='',returncode=0)
    except Exception as e:return jsonify(success=False,error=str(e),stderr=str(e),returncode=1),400

@app.get('/api/status')
def status():
    d=deny()
    if d:return d
    try:return jsonify(success=True,docker=LXDRuntime.check_host(),ready=True)
    except Exception as e:return jsonify(success=False,ready=False,error=str(e)),503

if __name__=='__main__':
    if not API_KEY: raise SystemExit('Set ZVM_NODE_API_KEY before starting the Docker node agent.')
    app.run(host='0.0.0.0',port=PORT)
