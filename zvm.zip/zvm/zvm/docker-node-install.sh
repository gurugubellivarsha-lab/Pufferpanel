#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run: sudo bash docker-node-install.sh'; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg python3 python3-venv python3-pip
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/$(. /etc/os-release && echo "$ID")/gpg | gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
. /etc/os-release
ARCH=$(dpkg --print-architecture)
CODENAME=${VERSION_CODENAME:-$(. /etc/os-release; echo "$VERSION_CODENAME")}
echo "deb [arch=$ARCH signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$ID $CODENAME stable" >/etc/apt/sources.list.d/docker.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
cd "$(dirname "$0")"
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt
if [[ ! -f .env ]]; then cp .env.example .env; fi
if grep -q '^ZVM_NODE_API_KEY=CHANGE_' .env; then echo 'Edit .env and set a strong ZVM_NODE_API_KEY before starting node.py.'; exit 2; fi
install -d -m 0750 data backups
cat <<'MSG'
Docker Engine installed. Start the authenticated ZVM remote node agent:
  set -a; source .env; set +a
  venv/bin/python node.py
Run it under systemd or a process manager for production. Expose port 9000 only behind HTTPS/firewall.
MSG
