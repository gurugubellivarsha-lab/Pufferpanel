#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./install.sh"; exit 1; fi

# Install the host container runtime first. The installer intentionally refuses
# to repair/remove unknown broken packages automatically.
bash ./install-lxc-lxd.sh
export DEBIAN_FRONTEND=noninteractive
apt-get install -y python3 python3-pip python3-venv
install -d -m 0750 data backups
if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo "Created .env. Set a strong SECRET_KEY and MAIN_ADMIN_PASSWORD before exposing the panel."
fi
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt
chmod +x start.sh zvm-tool.sh
venv/bin/python -m py_compile zvm.py lxd_backend.py api.py kvm_backend.py node.py vps_animation_routes.py
printf '\nZVM Panel V2 dependencies installed. Edit .env, then run ./start.sh\n'
