# ZVM Panel V2 release notes

## Runtime migration
- Replaced the Docker runtime adapter with `lxd_backend.py`.
- Added LXD instance lifecycle operations: launch, start, stop, restart, freeze, unfreeze, delete, info, exec, memory/CPU limits, root disk sizing, and TCP/UDP proxy devices.
- Added host SSH proxy allocation in the 22000-22999 range for newly created local instances.
- Updated the remote node agent to accept only allowlisted `lxc` client operations and require the API key when configured.
- Added `install-lxc-lxd.sh` to install LXD through Snap and initialize a default storage/network configuration when needed.
- Updated the panel installer, tool menu, health checks, system information, and runtime labels for LXD.
- Removed Docker deployment files and the Docker backend from this V2 archive.

## Important deployment notes
- LXD containers share the host Linux kernel; they are system containers, not KVM virtual machines.
- The VPS provider must permit LXD/nested container operation and the required kernel features.
- Confirm the default LXD profile has a working network and storage pool.
- Allow inbound TCP ports 22000-22999 in the VPS firewall/security group if SSH access from outside is required.
- Configure a strong `SECRET_KEY` and administrator password in `.env` before exposing port 3000.
- This archive has passed Python syntax compilation and static packaging checks. A live LXD provisioning/SSH/network test requires installation on the target VPS and was not run here.
