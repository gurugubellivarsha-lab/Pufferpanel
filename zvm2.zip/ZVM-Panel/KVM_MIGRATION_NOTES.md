# KVM backend (separate from ZVM V2 LXD runtime)

`kvm_backend.py` remains an experimental, optional libvirt/KVM worker. ZVM Panel V2 uses `lxd_backend.py` for system-container provisioning. LXD containers share the host kernel and are not KVM virtual machines. Do not select the KVM backend unless the host has `/dev/kvm`, libvirt, `virt-install`, and trusted cloud images configured.
