#!/usr/bin/env python3
"""ZVM LXD Node Agent V2. Exposes a restricted LXD command interface."""
import os, shlex, subprocess, platform, shutil
from flask import Flask, jsonify, request

app = Flask(__name__)
API_KEY = os.getenv('ZVM_NODE_API_KEY', '')
PORT = int(os.getenv('PORT', '9000'))


def auth():
    return (not API_KEY) or request.headers.get('X-API-Key') == API_KEY


def run(argv, timeout=120):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout, p.stderr


@app.get('/api/info')
def info():
    if not auth(): return jsonify(success=False, error='Unauthorized'), 401
    return jsonify(success=True, version='ZVM LXD Node 2.0', python_version=platform.python_version(), lxc=shutil.which('lxc') or 'not-found')


@app.post('/api/execute')
def execute():
    if not auth(): return jsonify(success=False, error='Unauthorized'), 401
    data = request.get_json(silent=True) or {}
    command = str(data.get('command', '')).strip()
    timeout = max(1, min(int(data.get('timeout', 120)), 900))
    try:
        argv = shlex.split(command)
        if not argv or argv[0] != 'lxc':
            return jsonify(success=False, error='Only LXC client commands are allowed'), 400
        # Disallow arbitrary host-shell execution and configuration of unrelated remotes.
        allowed = {'launch','init','start','stop','restart','freeze','unfreeze','delete','info','list','exec','config','version','storage','network'}
        if len(argv) < 2 or argv[1] not in allowed:
            return jsonify(success=False, error='LXC operation is not allowed'), 400
        if argv[1] == 'exec' and '--' not in argv:
            return jsonify(success=False, error='lxc exec requires -- before the container command'), 400
        code, out, err = run(argv, timeout)
        return jsonify(success=code == 0, stdout=out, stderr=err, returncode=code)
    except Exception as e:
        return jsonify(success=False, error=str(e)), 500


@app.get('/api/status')
def status():
    if not auth(): return jsonify(success=False, error='Unauthorized'), 401
    code, out, err = run(['lxc', 'info'], 15)
    version_code, version, version_err = run(['lxc', 'version'], 15)
    return jsonify(success=code == 0 and version_code == 0, lxd_version=version.strip() if version_code == 0 else None, error=err.strip() if code else version_err.strip() if version_code else None)


@app.post('/api/container/<action>')
def container_action(action):
    if not auth(): return jsonify(success=False, error='Unauthorized'), 401
    if action not in {'start','stop','restart','freeze','unfreeze','delete'}:
        return jsonify(success=False, error='Invalid action'), 400
    name = str((request.get_json(silent=True) or {}).get('container', '')).strip()
    if not name or not all(c.isalnum() or c in '_.-' for c in name):
        return jsonify(success=False, error='Valid container name required'), 400
    argv = ['lxc', 'delete', name, '--force'] if action == 'delete' else ['lxc', action, name]
    code, out, err = run(argv, 120)
    return jsonify(success=code == 0, stdout=out, stderr=err)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=PORT)
