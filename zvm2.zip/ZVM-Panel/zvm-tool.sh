#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$(readlink -f "$0")")"
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./zvm-tool.sh"; exit 1; fi
while true; do
  clear || true
  echo '╔══════════════════════════════════════════════╗'
  echo '║              ZVM TOOLS • V2                 ║'
  echo '╚══════════════════════════════════════════════╝'
  echo '  1. Start ZVM Panel'
  echo '  2. Install / initialize LXC + LXD'
  echo '  3. LXD status and instances'
  echo '  4. Install Cloudflare Tunnel'
  echo '  0. Exit'
  read -r -p 'Choose [0-4]: ' choice
  case "$choice" in
    1) ./start.sh ;;
    2) bash ./install-lxc-lxd.sh ;;
    3) lxc version || true; lxc info || true; lxc list || true ;;
    4)
      apt-get update && apt-get install -y curl
      curl -fsSL https://pkg.cloudflare.com/cloudflare-public-v2.gpg | tee /usr/share/keyrings/cloudflare-public-v2.gpg >/dev/null
      echo 'deb [signed-by=/usr/share/keyrings/cloudflare-public-v2.gpg] https://pkg.cloudflare.com/cloudflared any main' > /etc/apt/sources.list.d/cloudflared.list
      apt-get update && apt-get install -y cloudflared
      read -r -s -p 'Cloudflare Tunnel Token: ' token; echo
      [[ -n "$token" ]] && cloudflared service install "$token"
      ;;
    0) exit 0 ;;
    *) echo 'Invalid choice.' ;;
  esac
  read -r -p 'Press Enter to continue...' _
done
