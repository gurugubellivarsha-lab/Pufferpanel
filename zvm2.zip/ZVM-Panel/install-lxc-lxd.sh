#!/usr/bin/env bash
set -Eeuo pipefail

# ZVM Panel V2: install and initialize LXD (which provides the `lxc` client).
if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run as root: sudo bash install-lxc-lxd.sh" >&2
  exit 1
fi

. /etc/os-release
if [[ "${ID:-}" != ubuntu && "${ID:-}" != debian ]]; then
  echo "Supported hosts: Ubuntu or Debian. Detected: ${PRETTY_NAME:-unknown}" >&2
  exit 1
fi

if command -v dpkg >/dev/null 2>&1; then
  audit="$(dpkg --audit 2>&1 || true)"
  if [[ -n "$audit" ]]; then
    echo "dpkg reports packages needing repair. Fix package-manager state before installing LXD:" >&2
    printf '%s\n' "$audit" >&2
    echo "This script will not forcibly remove cPanel packages or alter your hosting stack." >&2
    exit 20
  fi
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y snapd ca-certificates curl
systemctl enable --now snapd.socket 2>/dev/null || true
systemctl start snapd 2>/dev/null || true

if ! command -v snap >/dev/null 2>&1; then
  echo "snap command is unavailable. Reboot the VPS and rerun this script." >&2
  exit 21
fi

if ! snap list lxd >/dev/null 2>&1; then
  snap install lxd
fi

# Make snap binaries available in this shell and future login shells.
export PATH="/snap/bin:$PATH"
ln -sf /snap/bin/lxc /usr/local/bin/lxc
ln -sf /snap/bin/lxd /usr/local/bin/lxd

systemctl enable --now snapd
lxd waitready --timeout=600
if ! lxc storage list --format csv -c n 2>/dev/null | grep -q .; then
  lxd init --auto
fi

lxc version
lxc info >/dev/null
printf '\nLXD is installed and initialized. Check instances with: lxc list\n'
printf 'ZVM V2 can now use the LXD runtime.\n'
