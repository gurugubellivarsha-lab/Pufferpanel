# ZVM Panel

ZVM Panel is the rebranded Flask application based on the original NRB project. It keeps the Python backend and separate HTML templates.

## Quick start (Ubuntu/Debian or Codespaces)

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python zvm.py
```

Or use `bash start.sh` to create the virtual environment, install dependencies, and start the panel.

The web panel listens on port `3000` by default. In GitHub Codespaces, forward port 3000 in the Ports tab.

## Database and files

- The database defaults to `zvm.db` in the project root, beside `zvm.py`.
- No `data/` directory or `.env` file is required.
- Optional environment variables can override settings, including `DATABASE_PATH`, `HOST`, `PORT`, `SECRET_KEY`, and administrator credentials.
- The original `nrb.db` is not copied into this project.

## Initial administrator

On a fresh database, the default initial administrator username is `admin` and password is `admin`. **Immediately change this password after signing in** before exposing the panel to any network. Existing databases keep their existing administrator account/password; changing environment defaults does not reset an existing account.

## Docker

Docker deployment needs a Docker daemon and appropriate host permissions. Containers are not full virtual machines. Full VM hosting requires a correctly configured KVM/libvirt host. Real VPS creation, SSH, and KVM operations must be tested on the target host before production use.

## Repair notes
- Fixed missing Jinja templates referenced by the suspended-VPS page and admin node detail page.
- Startup script now changes to the project directory before running, so relative assets and backup paths behave consistently.
- Static validation performed: Python syntax parsing, Flask route parity against the source panel, and literal template/include reference checks.
- A live HTTP smoke test still requires installing the dependencies and running on your target server; this environment has no package-network access.
